import bpy, json, math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARTS = ROOT / "parts"
M = json.load(open(ROOT / "manifest.json", encoding="utf-8"))
W, H = M["canvas"]
PPU = 100.0
Z_STEP = 0.002

bpy.ops.wm.read_factory_settings(use_empty=True)

def make_mesh(name, w, h):
    # one textured quad only: neutral sanity check, no deformation yet
    me = bpy.data.meshes.new(name + "_Mesh")
    me.from_pydata(
        [(-w/2,-h/2,0),(w/2,-h/2,0),(w/2,h/2,0),(-w/2,h/2,0)],
        [], [(0,1,2,3)]
    )
    me.update()
    uv = me.uv_layers.new(name="UVMap")
    # Blender UV origin is lower-left.
    coords = [(0,0),(1,0),(1,1),(0,1)]
    poly = me.polygons[0]
    for li, uvco in zip(poly.loop_indices, coords):
        uv.data[li].uv = uvco
    return me

def make_mat(name, path):
    m = bpy.data.materials.new("MAT_" + name)
    m.use_nodes = True
    if hasattr(m, "surface_render_method"):
        m.surface_render_method = 'BLENDED'
    nt = m.node_tree
    nt.nodes.clear()

    out = nt.nodes.new("ShaderNodeOutputMaterial")
    mix = nt.nodes.new("ShaderNodeMixShader")
    tr  = nt.nodes.new("ShaderNodeBsdfTransparent")
    em  = nt.nodes.new("ShaderNodeEmission")
    tx  = nt.nodes.new("ShaderNodeTexImage")

    # Fully transparent branch must be pure white.
    tr.inputs["Color"].default_value = (1,1,1,1)
    tx.interpolation = 'Linear'
    tx.extension = 'CLIP'
    img = bpy.data.images.load(str(path), check_existing=True)
    img.alpha_mode = 'STRAIGHT'
    tx.image = img

    nt.links.new(tx.outputs["Color"], em.inputs["Color"])
    nt.links.new(tx.outputs["Alpha"], mix.inputs[0])
    nt.links.new(tr.outputs[0], mix.inputs[1])
    nt.links.new(em.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs["Surface"])
    return m

art = bpy.data.collections.new("XLG_NEUTRAL_57")
bpy.context.scene.collection.children.link(art)

for p in sorted(M["parts"], key=lambda q:q["z_index"]):
    n = p["name"]
    l,t,r,b = p["crop_bbox"]
    wp, hp = r-l, b-t
    o = bpy.data.objects.new(n, make_mesh(n, wp/PPU, hp/PPU))
    art.objects.link(o)
    o.location = (
        ((l+r)/2 - W/2) / PPU,
        (H/2 - (t+b)/2) / PPU,
        p["z_index"] * Z_STEP
    )
    o.data.materials.append(make_mat(n, PARTS / f"{n}.png"))

sc = bpy.context.scene
sc.render.engine = 'BLENDER_EEVEE_NEXT'
sc.render.resolution_x = 471
sc.render.resolution_y = 836
sc.render.resolution_percentage = 100
sc.render.film_transparent = True
sc.render.image_settings.file_format = 'PNG'
sc.render.image_settings.color_mode = 'RGBA'
sc.render.image_settings.color_depth = '8'

# Camera centered on the ORIGINAL 941x1672 canvas, not derived from deformed bboxes.
cd = bpy.data.cameras.new("Camera")
cam = bpy.data.objects.new("Camera", cd)
bpy.context.scene.collection.objects.link(cam)
cam.location = (0.0, 0.0, 20.0)
cam.rotation_euler = (0.0, 0.0, 0.0)
cd.type = 'ORTHO'
aspect = sc.render.resolution_x / sc.render.resolution_y
canvas_h = H / PPU
canvas_w = W / PPU
cd.ortho_scale = max(canvas_h, canvas_w/aspect) * 1.01
sc.camera = cam

# Neutral validation only.
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)
sc.render.filepath = str(OUT / "Neutral_REAL_FULL57.png")
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT / "XLG_Neutral_REAL_FULL57.blend"))

# Basic alpha bounding-box audit from the saved PNG will be performed by Pillow in build.
print("NEUTRAL57_DONE", OUT)
